import cv2
import numpy as np
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import Qt
from skimage import measure, filters
import os
from PIL import Image
from numpy.linalg import norm

def brightness(img):
    if len(img.shape) == 3:
        # RGB or BGR image
        return np.average(norm(img, axis=2)) / np.sqrt(3)
    else:
        # Grayscale image
        return np.average(img)

def load_image(image_processor, key):
    fname, _ = QFileDialog.getOpenFileName(image_processor, 'Open file', '.', "Image files (*.jpg *.png *.jpeg *.bmp)")
    if fname:
        image = cv2.imread(fname)
        if image is not None:
            original_key = f'original_{key}'
            image_processor.images[original_key] = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Store original image in RGB format
            image_processor.images[key] = image_processor.images[original_key].copy()  # Copy for processing

            # Calculate brightness using the Euclidean norm method
            img_brightness = brightness(image_processor.images[key])
            image_processor.original_brightness[key] = img_brightness
            print(f"Brightness of {key} ({os.path.basename(fname)}): {img_brightness:.2f}")

            # Update label with filename and brightness
            filename = os.path.splitext(os.path.basename(fname))[0]
            if key == 'image1':
                image_processor.image_name_label1.setText(filename)
            elif key == 'image2':
                image_processor.image_name_label2.setText(filename)

            display_image(image_processor, key)


def display_image(image_processor, key):
    if key in image_processor.images and image_processor.images[key] is not None:
        print(f"Displaying image for {key}")
        image = image_processor.images[key]
        print(f"Brightness for {key}: {image_processor.last_brightness.get(key, 'Not Set')}")
        print(f"Contrast for {key}: {image_processor.last_contrast.get(key, 'Not Set')}")
        height, width, channels = image.shape
        bytes_per_line = 3 * width
        q_img = QImage(image.data, width, height, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(q_img)
        label = image_processor.image_label1 if key == 'image1' else image_processor.image_label2
        label.setPixmap(pixmap.scaled(label.size(), Qt.KeepAspectRatio))
        label.show()
              
    else:
        print(f"No image to display for {key}")

def update_sliders_and_labels(image_processor, key):
    if key in image_processor.last_brightness:
        brightness = image_processor.last_brightness[key]
        image_processor.brightness_slider.setValue(brightness)
        image_processor.brightness_value_label.setText(str(brightness))

    if key in image_processor.last_contrast:
        contrast = image_processor.last_contrast[key] * 100  # Assuming contrast needs to be multiplied by 100 for the slider
        image_processor.contrast_slider.setValue(int(contrast))
        image_processor.contrast_value_label.setText(f"{contrast / 100:.1f}")

def update_brightness(image_processor):
    key = image_processor.current_image_key
    if key and f'original_{key}' in image_processor.images:
        original_image = image_processor.images[f'original_{key}']
        value = image_processor.brightness_slider.value()
        brightness = value  # Center brightness around 0
        contrast = float(image_processor.contrast_input.text())
        updated_image = cv2.convertScaleAbs(original_image, alpha=contrast, beta=brightness)
        image_processor.images[key] = updated_image
        # Save the last applied settings
        image_processor.last_brightness[key] = brightness
        image_processor.last_contrast[key] = contrast
        display_image(image_processor, key)

def update_brightness_from_input(image_processor):
    try:
        value = int(image_processor.brightness_input.text())
        image_processor.brightness_slider.setValue(value)
        update_brightness(image_processor)
    except ValueError:
        image_processor.brightness_input.setText(str(image_processor.brightness_slider.value()))
        print("Invalid input for brightness. Please enter an integer.")

def update_contrast(image_processor):
    key = image_processor.current_image_key
    if key and f'original_{key}' in image_processor.images:
        original_image = image_processor.images[f'original_{key}']
        contrast = float(image_processor.contrast_slider.value()) / 100.0
        brightness = image_processor.brightness_slider.value()
        updated_image = cv2.convertScaleAbs(original_image, alpha=contrast, beta=brightness)
        image_processor.images[key] = updated_image
        # Save the last applied settings
        image_processor.last_brightness[key] = brightness
        image_processor.last_contrast[key] = contrast
        display_image(image_processor, key)

def update_contrast_from_input(image_processor):
    try:
        value = float(image_processor.contrast_input.text())
        image_processor.contrast_slider.setValue(int(value * 100))
        update_contrast(image_processor)
    except ValueError:
        image_processor.contrast_input.setText(f"{image_processor.contrast_slider.value() / 100:.2f}")
        print("Invalid input for contrast. Please enter a float.")

def enhance_images(image_processor):
    keys = ['image1', 'image2']
     # Define the size of the kernel for the morphological operation
    max_object_size = 2500
    
    for key in keys:
        original_key = f'original_{key}'
        if original_key in image_processor.images and image_processor.images[original_key] is not None:
            print(f"Enhancing {key} from original image.")
            input_image = image_processor.images[original_key].copy()

            # Retrieve current brightness and contrast values from the UI
            contrast = float(image_processor.contrast_input.text())
            brightness = image_processor.brightness_slider.value()

            # Apply brightness and contrast adjustments
            image_weighted = cv2.addWeighted(input_image, contrast, input_image, 0, brightness)

            # Convert to grayscale
            gray_enhanced = cv2.cvtColor(image_weighted, cv2.COLOR_BGR2GRAY)

            if key == 'image1':
                _, binary_otsu = cv2.threshold(gray_enhanced, 50, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                
            if key == 'image2':
                _, binary_otsu = cv2.threshold(gray_enhanced, 50, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

            brightness_value = image_processor.original_brightness.get('image2', 0)
            kernel_size = 9 if brightness_value > 29 else 6
            print(f"Kernel size for images: {kernel_size} (based on original image2 brightness {brightness_value:.2f})")

            # Prepare the morphological operation
            kernel = np.ones((kernel_size, kernel_size), np.uint8)
            image_adjusted = cv2.morphologyEx(binary_otsu, cv2.MORPH_OPEN, kernel)
            
            labeled_image, num_features = measure.label(image_adjusted, return_num=True, connectivity=2, background=0) # labels and counts connected regions in the binary image
            properties = measure.regionprops(labeled_image) # computed properties of labeled regions
            max_filtered_regions = [prop for prop in properties if prop.area <= max_object_size] # filters out regions that are more than max size
            image_adjusted_max_filtered = np.zeros_like(image_adjusted) # new binary image with same dimension as the original binary image
            for region in max_filtered_regions:
                image_adjusted_max_filtered += (labeled_image == region.label).astype(np.uint8) * 255 # creates binary mask of 0 and 255 and adds it to the new image

            # Convert back to RGB for display (if needed)
            image_adjusted_rgb = cv2.cvtColor(image_adjusted, cv2.COLOR_GRAY2RGB)

            # Update the image in the processor and display
            image_processor.images[key] = image_adjusted_rgb
            display_image(image_processor, key)
        else:
            print(f"Original image not found for {key}, unable to enhance.")


def process_overlap(image_processor):
    if 'image1' in image_processor.images and 'image2' in image_processor.images:
        image1 = cv2.cvtColor(image_processor.images['image1'], cv2.COLOR_RGB2GRAY)
        image2 = cv2.cvtColor(image_processor.images['image2'], cv2.COLOR_RGB2GRAY)
        overlap = cv2.bitwise_and(image1, image2)
        
        labeled_image, num_features = measure.label(overlap, return_num=True, connectivity=2, background=0)

        properties = measure.regionprops(labeled_image)

        min_white_pixels = 10
        filtered_regions = [prop for prop in properties if prop.area > min_white_pixels]

        large_cells_count = len(filtered_regions)
        # Update the label with the count of large cells
        image_processor.overlap_count_label.setText(f"Overlap Count: {large_cells_count}")
        
#         overlap_image = cv2.cvtColor(overlap, cv2.COLOR_GRAY2RGB)
#         image_processor.images['overlap'] = overlap_image
#         display_image(image_processor, 'overlap')

