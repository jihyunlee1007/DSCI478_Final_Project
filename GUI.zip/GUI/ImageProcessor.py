from PyQt5.QtWidgets import QMainWindow, QVBoxLayout, QWidget, QLabel, QSizePolicy, QPushButton
from GuiComponents import setup_controls, setup_buttons
from ClickableLabel import ClickableLabel
from PyQt5.QtCore import Qt

class ImageProcessor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.images = {}
        self.current_image_key = None
        self.last_brightness = {}
        self.last_contrast = {}
        self.original_brightness = {}
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Image Processor')
        self.setGeometry(100, 100, 600, 1000)

        # Main vertical layout
        self.layout = QVBoxLayout()

        self.reset_button = QPushButton('Reset', self)
        self.reset_button.setFixedSize(150, 30)
        self.reset_button.clicked.connect(self.reset)  # Connect to reset function
        self.layout.addWidget(self.reset_button)
        self.layout.setAlignment(self.reset_button, Qt.AlignRight)
        
        # Label for displaying the overlap count
        self.overlap_count_label = QLabel("Overlap Count: Not processed yet")
        self.overlap_count_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.overlap_count_label)
        self.overlap_count_label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)

        # Image 1 and its label
        self.image_label1 = ClickableLabel(self)
        self.image_label1.clicked.connect(lambda: self.set_current_image('image1'))
        self.image_label1.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.image_label1)
        self.image_name_label1 = QLabel("No Image 1 Loaded")
        self.image_name_label1.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.image_name_label1.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.image_name_label1)

        # Image 2 and its label
        self.image_label2 = ClickableLabel(self)
        self.image_label2.clicked.connect(lambda: self.set_current_image('image2'))
        self.image_label2.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.image_label2)
        self.image_name_label2 = QLabel("No Image 2 Loaded")
        self.image_name_label2.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.image_name_label2.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.image_name_label2)

        # Setup controls and buttons
        setup_controls(self)
        setup_buttons(self)

        # Set the central widget
        central_widget = QWidget()
        central_widget.setLayout(self.layout)
        self.setCentralWidget(central_widget)

    def set_current_image(self, key):
        self.current_image_key = key
        print(f"Current image set to {key}")

    def reset(self):
        # Clear the images from the processor
        self.images.clear()
        self.current_image_key = None
        self.last_brightness.clear()
        self.last_contrast.clear()

        # Clear the image labels
        self.image_label1.clear()
        self.image_label2.clear()
        self.image_name_label1.setText("No Image 1 Loaded")
        self.image_name_label2.setText("No Image 2 Loaded")

        # Reset sliders and labels to default values
        self.brightness_slider.setValue(0)
        self.brightness_value_label.setText("0")
        self.contrast_slider.setValue(100)
        self.contrast_value_label.setText("1.0")

        # Reset overlap count label
        self.overlap_count_label.setText("Overlap Count: Not processed yet")

        self.last_brightness.clear()
        self.last_contrast.clear()

