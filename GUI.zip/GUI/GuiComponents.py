from PyQt5.QtWidgets import QLabel, QSlider, QLineEdit, QHBoxLayout, QVBoxLayout, QPushButton
from PyQt5.QtCore import Qt
from ImageOperations import load_image, update_brightness, update_contrast, process_overlap, update_brightness_from_input, update_contrast_from_input, enhance_images


def setup_controls(image_processor):
    # Brightness controls setup
    brightness_label = QLabel('Brightness:')
    image_processor.brightness_slider = QSlider(Qt.Horizontal)
    image_processor.brightness_slider.setRange(-100, 100)
    image_processor.brightness_slider.setValue(0)
    image_processor.brightness_value_label = QLabel("0")  # Label to display the current brightness value
    image_processor.brightness_input = QLineEdit("0")
    image_processor.brightness_input.setFixedWidth(50)

    # Connect brightness slider to update the label and input
    image_processor.brightness_slider.valueChanged.connect(lambda: update_brightness(image_processor))
    image_processor.brightness_slider.valueChanged.connect(lambda: image_processor.brightness_value_label.setText(str(image_processor.brightness_slider.value())))
    image_processor.brightness_input.editingFinished.connect(lambda: update_brightness_from_input(image_processor))

    # Contrast controls setup
    contrast_label = QLabel('Contrast:')
    image_processor.contrast_slider = QSlider(Qt.Horizontal)
    image_processor.contrast_slider.setRange(0, 500)
    image_processor.contrast_slider.setValue(100)
    image_processor.contrast_value_label = QLabel("1.0")  # Label to display the current contrast value
    image_processor.contrast_input = QLineEdit("1.0")
    image_processor.contrast_input.setFixedWidth(50)

    # Connect contrast slider to update the label and input
    image_processor.contrast_slider.valueChanged.connect(lambda: update_contrast(image_processor))
    image_processor.contrast_slider.valueChanged.connect(lambda: image_processor.contrast_value_label.setText(f"{image_processor.contrast_slider.value() / 100:.2f}"))
    image_processor.contrast_input.editingFinished.connect(lambda: update_contrast_from_input(image_processor))

    # Layout setup for brightness and contrast controls
    brightness_layout = QHBoxLayout()
    brightness_layout.addWidget(brightness_label)
    brightness_layout.addWidget(image_processor.brightness_slider)
    brightness_layout.addWidget(image_processor.brightness_value_label)
    brightness_layout.addWidget(image_processor.brightness_input)

    contrast_layout = QHBoxLayout()
    contrast_layout.addWidget(contrast_label)
    contrast_layout.addWidget(image_processor.contrast_slider)
    contrast_layout.addWidget(image_processor.contrast_value_label)
    contrast_layout.addWidget(image_processor.contrast_input)

    # Main layout
    control_layout = QVBoxLayout()
    control_layout.addLayout(brightness_layout)
    control_layout.addLayout(contrast_layout)
    image_processor.layout.addLayout(control_layout)

def setup_buttons(image_processor):
    image_processor.load_image1_button = QPushButton('Load Image 1', image_processor)
    image_processor.load_image2_button = QPushButton('Load Image 2', image_processor)
    image_processor.enhance_button = QPushButton('Detect Cells', image_processor)
    image_processor.process_button = QPushButton('Count Overlapping Cells', image_processor)

    
    # Connet to functions
    image_processor.load_image1_button.clicked.connect(lambda: load_image(image_processor, 'image1'))
    image_processor.load_image2_button.clicked.connect(lambda: load_image(image_processor, 'image2'))
    image_processor.enhance_button.clicked.connect(lambda: enhance_images(image_processor))
    image_processor.process_button.clicked.connect(lambda: process_overlap(image_processor))
    
    # Add button to layout
    image_processor.layout.addWidget(image_processor.load_image1_button)
    image_processor.layout.addWidget(image_processor.load_image2_button)
    image_processor.layout.addWidget(image_processor.enhance_button)
    image_processor.layout.addWidget(image_processor.process_button)
